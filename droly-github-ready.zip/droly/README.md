# Droly

MVP d'un service qui transforme les photos d'une annonce immobilière (Airbnb,
Leboncoin…) en vidéo de visite façon travelling drone. Concept d'exploration
inspiré de dronly.co, non affilié.

## Ce qu'il y a dans ce repo

```
droly/
├── index.html        ← le site (page d'accueil, essai, questionnaire, paiement démo)
├── videos/            ← les 5 vidéos de démonstration utilisées par le site
│   ├── hero.mp4
│   ├── salon.mp4
│   ├── cuisine.mp4
│   ├── piscine.mp4
│   └── drone.mp4
└── api/                ← petit serveur optionnel pour générer de VRAIES vidéos (API Runway)
    ├── server.js
    ├── package.json
    ├── .env.example
    └── README.md        ← instructions détaillées pour cette partie
```

Le site (`index.html` + `videos/`) fonctionne seul, sans rien installer :
c'est du HTML/CSS/JS pur, aucune dépendance. Les vidéos sont de vrais
fichiers `.mp4` référencés en local (`videos/hero.mp4`, etc.) — pas de lien
externe qui peut casser.

## Voir le site en local avant de publier

Le plus fiable est de lancer un petit serveur local (les navigateurs sont
parfois capricieux avec les vidéos ouvertes en double-clic direct) :

```bash
cd droly
python3 -m http.server 8000
# puis ouvre http://localhost:8000 dans ton navigateur
```

(Ou n'importe quel autre serveur statique : `npx serve`, l'extension "Live
Server" de VS Code, etc. Double-cliquer sur `index.html` fonctionne aussi
dans la plupart des navigateurs.)

## Publier sur GitHub (avec les vidéos qui marchent)

1. Crée un nouveau repo sur GitHub (vide, sans README ni .gitignore générés
   automatiquement — ce dossier en a déjà, et il est déjà initialisé en Git
   avec un premier commit sur la branche `main`, prêt à pousser).
2. Dans ce dossier `droly/`, connecte-le à ton repo et pousse :
   ```bash
   git remote add origin https://github.com/TON-COMPTE/TON-REPO.git
   git push -u origin main
   ```
3. Une fois poussé, va dans **Settings → Pages** de ton repo GitHub.
4. Dans "Build and deployment" → Source, choisis **Deploy from a branch**,
   branche **main**, dossier **/ (root)**. Enregistre.
5. GitHub te donne une adresse du style
   `https://TON-COMPTE.github.io/TON-REPO/` — le site (et les vidéos) sont
   en ligne dessus après 1 à 2 minutes.

Comme les vidéos sont de vrais fichiers dans `videos/` (pas des liens
externes ni du texte encodé dans la page), elles se chargent normalement,
en streaming, comme n'importe quelle vidéo web — GitHub Pages les sert
sans problème.

## Mode démo vs mode réel

Par défaut, le bouton "Essayer" simule une génération (démo, pour montrer
le principe sans rien payer). Pour brancher la vraie génération de vidéo
(API Runway) :

1. Déploie le petit serveur du dossier `api/` — voir `api/README.md`
   pour les instructions complètes, pas à pas.
2. Dans `index.html`, remplace la ligne `var DROLY_API_BASE = '';` par
   l'URL de ce serveur.

Sans cette étape, le site fonctionne quand même très bien en démo — rien
n'est cassé si tu ne déploies pas l'API.

## Notes

- Aucune carte bancaire n'est réellement débitée nulle part dans ce MVP —
  le formulaire de paiement est une simulation, clairement indiquée comme
  telle sur la page.
- La clé API Runway (si tu l'utilises) ne doit jamais être mise dans
  `index.html` ni commit dans Git — elle reste côté serveur (`api/.env`,
  qui est ignoré par `.gitignore`).
