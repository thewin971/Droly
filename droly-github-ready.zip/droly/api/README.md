# Droly API

Petit serveur (Node.js) qui fait le pont entre la page Droly et l'API
Runway pour générer une vraie vidéo à partir d'une photo.

## Pourquoi un serveur, et pas juste du code dans la page ?

La page Droly (`index.html` à la racine du repo) est un fichier HTML public :
n'importe qui peut voir son code source. Si la clé secrète Runway était écrite dedans,
n'importe qui pourrait la copier et l'utiliser à tes frais. Ce petit
serveur garde la clé cachée côté serveur, et c'est lui qui parle à Runway
— la page ne fait que lui envoyer une requête.

```
Page Droly (navigateur)  →  ce serveur (garde la clé)  →  API Runway
```

## 1. Récupérer une clé API Runway

1. Va sur https://dev.runwayml.com/login et crée un compte (ou connecte-toi).
2. Dans le tableau de bord, crée une clé API ("API key" / "Secret key").
3. Garde-la précieusement — c'est ce qui va dans `RUNWAYML_API_SECRET`.

Runway facture l'utilisation de l'API en crédits (pas d'abonnement Droly
là-dedans, c'est séparé) — regarde leur page de tarifs avant de tester en
volume.

## 2. Lancer le serveur en local (pour tester)

```bash
npm install
cp .env.example .env
# ouvre .env et colle ta vraie clé Runway dans RUNWAYML_API_SECRET
npm start
```

Le serveur écoute sur `http://localhost:3000`. Teste-le :

```bash
curl http://localhost:3000/health
# {"ok":true}

curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"imageUrl": "https://LIEN-DIRECT-VERS-UNE-PHOTO.jpg"}'
```

La génération prend en général 30 à 90 secondes — c'est normal, la requête
reste ouverte jusqu'à ce que la vidéo soit prête.

**Important : `imageUrl` doit être un lien DIRECT vers une image**
(qui se termine par `.jpg`, `.png`…), pas un lien vers une page d'annonce
Airbnb ou Leboncoin. Aller chercher automatiquement toutes les photos
d'une page d'annonce (« scraper ») est une autre étape, plus fragile et
pas toujours autorisée par les conditions d'utilisation de ces sites — je
n'ai pas construit ça ici. Pour avoir un lien direct vers une image :
clic droit sur une photo → « Copier l'adresse de l'image ».

## 3. Mettre le serveur en ligne (déploiement)

Il faut qu'il tourne quelque part en permanence pour que la page Droly
puisse l'appeler. Le plus simple pour démarrer : **Render**
(render.com) — il y a une offre gratuite pour un petit service comme
celui-ci (vérifie les conditions actuelles, ça change parfois). Railway
ou Fly.io fonctionnent aussi.

Sur Render :
1. Crée un compte, "New +" → "Web Service".
2. Connecte le repo GitHub qui contient ce dossier.
3. **Important** : comme `api/` est un sous-dossier du repo (et pas la
   racine), règle "Root Directory" sur `api` dans les paramètres du
   service. Sans ça, Render cherche `package.json` à la racine et ne le
   trouve pas.
4. Build command : `npm install` — Start command : `npm start`.
5. Dans "Environment", ajoute la variable `RUNWAYML_API_SECRET` avec ta
   clé (jamais dans le code, toujours dans les variables d'environnement
   de l'hébergeur).
6. Déploie. Render te donne une URL du style
   `https://droly-api.onrender.com`.

## 4. Connecter la page Droly à ce serveur

Une fois déployé, ouvre `index.html` (à la racine du repo), cherche la
ligne suivante (vers la ligne 640, juste avant `function showStep`) :

```js
var DROLY_API_BASE = '';
```

Remplace les guillemets vides par l'URL obtenue à l'étape précédente
(sans slash à la fin), par exemple :

```js
var DROLY_API_BASE = 'https://droly-api.onrender.com';
```

Enregistre, commit, push. À partir de là, coller une vraie image dans le
champ déclenche une vraie génération Runway au lieu de la démo simulée.
Si tu préfères, tu peux aussi me redonner l'URL ici et je fais la
modification pour toi.
