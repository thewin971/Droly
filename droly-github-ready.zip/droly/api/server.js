// Droly API — petit serveur qui fait le pont entre la page Droly
// et l'API Runway (génération vidéo à partir d'une photo).
//
// Pourquoi ce serveur existe :
// la clé secrète Runway ne doit JAMAIS être écrite dans le HTML/JS de la
// page (artifact) : n'importe qui peut lire le code source d'une page web
// et la voler. Ce serveur garde la clé côté serveur (variable d'environnement)
// et expose une seule route que la page appelle.

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import RunwayML, { TaskFailedError } from '@runwayml/sdk';

const PORT = process.env.PORT || 3000;

if (!process.env.RUNWAYML_API_SECRET) {
  console.warn('[droly-api] ATTENTION: RUNWAYML_API_SECRET n\'est pas défini (voir .env.example).');
}

const client = new RunwayML(); // lit RUNWAYML_API_SECRET automatiquement dans l'environnement

const app = express();
app.use(cors()); // MVP: ouvert à tous les domaines. À restreindre plus tard (voir README).
app.use(express.json({ limit: '5mb' }));

app.get('/health', (req, res) => {
  res.json({ ok: true });
});

// POST /api/generate
// body attendu : { imageUrl: string, promptText?: string, ratio?: string, duration?: number }
// - imageUrl DOIT être un lien direct vers une image (jpg/png/webp), pas un lien
//   vers une page d'annonce Airbnb/Leboncoin. Voir le README pour pourquoi.
app.post('/api/generate', async (req, res) => {
  const { imageUrl, promptText, ratio, duration } = req.body || {};

  if (!imageUrl || typeof imageUrl !== 'string') {
    return res.status(400).json({ error: 'bad_request', message: 'imageUrl (lien direct vers une image) est requis.' });
  }

  try {
    const task = await client.imageToVideo
      .create({
        model: 'gen4.5',
        promptImage: imageUrl,
        promptText: promptText || 'Mouvement de caméra immobilier, travelling lent et cinématique, style visite virtuelle',
        ratio: ratio || '1280:720',
        duration: duration || 5,
      })
      .waitForTaskOutput();

    // Le champ exact qui contient l'URL vidéo peut varier selon la version de
    // l'API — on log la réponse complète côté serveur et on essaie les formes
    // les plus courantes. Regarde les logs Render/Railway si videoUrl est null.
    console.log('[droly-api] task output brut:', JSON.stringify(task.output ?? task, null, 2));

    let videoUrl = null;
    if (Array.isArray(task.output) && task.output.length > 0) {
      videoUrl = typeof task.output[0] === 'string' ? task.output[0] : task.output[0]?.url;
    } else if (task.output?.url) {
      videoUrl = task.output.url;
    }

    return res.json({ videoUrl, raw: task });
  } catch (err) {
    if (err instanceof TaskFailedError) {
      console.error('[droly-api] Runway a échoué à générer la vidéo:', err.taskDetails);
      return res.status(502).json({ error: 'generation_failed', message: 'Runway n\'a pas réussi à générer la vidéo.', details: err.taskDetails });
    }
    console.error('[droly-api] Erreur serveur:', err);
    return res.status(500).json({ error: 'server_error', message: String(err?.message || err) });
  }
});

app.listen(PORT, () => {
  console.log(`[droly-api] en écoute sur le port ${PORT}`);
});
